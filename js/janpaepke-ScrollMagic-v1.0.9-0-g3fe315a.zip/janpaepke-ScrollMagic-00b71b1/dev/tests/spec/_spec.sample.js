describe('MODULE NAME', function() {

	beforeEach(function() {

	});

	it("should succeed", function() {
		console.log("TEST SUCCEEDED");
	});

});
